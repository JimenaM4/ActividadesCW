<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Taller de escritura de monos</title>
    <link rel="icon" href="./icono_changuito.png" type="image/x-png">
    <link rel="stylesheet" href="./style_PHP.css">
</head>
<body>
    <?php
        $palabras=(isset($_POST['palabras']) && $_POST["palabras"] != "")? $_POST['palabras'] : "Falta Valor";
        $texto=(isset($_POST['tipotext']) && $_POST["tipotext"] !="")?$_POST['tipotext'] : "Falta Valor";
        $zona=(isset($_POST['zonah']) && $_POST["zonah"] != "")? $_POST['zonah'] : "Falta Valor";
        $libro=rand(1, 100000);
        $cuenta=1;
        echo "<table border='2'align='center' style='border-collapse:collapse;' cellpadding='20px';> 
            <thead>
                <tr>
                    <th><h1 align='center'>Resultados</h1></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Palabras de busqueda: $palabras</td>
                </tr>
                <tr>
                    <td>Modo de busqueda: $texto</td>
                </tr>
                <tr>
                    <td>Zona horaria: $zona</td>
                </tr>
                <tr>
                    <td><h3 align='center'>Libro número: $libro</h3></td>
                </tr>
                <tr>";
                echo "<td align='center'>";
                switch ($texto){
                    case "Normal":
                        for($i=0; $i<=1399; $i++){
                            $lugar=rand(0,1399);
                            $randconta=rand(65,126);
            
                            $rand[$i]= chr($randconta);
            
                                if($lugar === $i){
                                  $rand[$i] = $palabras;
                                  echo "     ";
                                  echo "<strong>$rand[$i]</strong>";
                                  echo "     ";
                                } else{
                                  echo "     ";
                                  echo $rand[$i];
                                  echo "     ";
                                }
                        }; 
                        break;
                    case "Palabras":
                        $limpal = explode(" ", $palabras);
                        $longitud = count ($limpal);
        
                        for($i=0; $i<=1399; $i++){
                            $randconta=rand(65,126);
            
                            $rand[$i]= chr($randconta);
                        };
        
                        for($i=0; $i<$longitud; $i++){
                            $randconta=rand(0,1399);
        
                            $rand[$randconta] = $limpal[$i];
                        };
        
                        for($i=0; $i<=1399; $i++){
                            if ($cuenta >=70) {
                                echo "     ";
                                echo $rand[$i];
                                echo "     ";
                                echo "<br>";
                                $cuenta=1;
                            } else {
                                echo "     ";
                                echo $rand[$i];
                                echo "     ";
                            }
                            $cuenta++;
                        };
                        break;
                    case "Orden":
                        $lugar=rand(0,1399);
                        $limpal = explode(" ", $palabras);
                        $longitud = count ($limpal);
                        $max= $lugar + $longitud;
        
                        shuffle($limpal);
                        $contPals=0;
        
                        for($i=0; $i<=1399; $i++){
                            $randconta=rand(65,126);
            
                            $rand[$i]= chr($randconta);
                        };
        
                        for($i = $lugar; $i < $max ; $i++){
                            $rand[$i]= $limpal[$contPals];
                            $contPals++;
                        };
                        for($i=0; $i<=1399; $i++){
                            if ($cuenta >=70) {
                                echo "     ";
                                echo $rand[$i];
                                echo "     ";
                                echo "<br>";
                                $cuenta=1;
                            } else {
                                echo "     ";
                                echo $rand[$i];
                                echo "     ";
                            }
                            $cuenta++;
                        };
                        break;
                }
                echo "</td>";
                echo "</tr>
            </tbody>
        </table>";
        //$hora= time();
        switch ($zona) {
            case 'Nueva York':
                date_default_timezone_set("America/New_York");
                $ZonaHorariaNY= date_default_timezone_get();
                echo "La consulta de este libro se hizo el: " .date("d-m-Y");
                echo " a las " .date("h:ia");
                echo " en " , $ZonaHorariaNY ;
                break;
            case 'Budapest':
                date_default_timezone_set("Europe/Budapest");
                $ZonaHorariaNY= date_default_timezone_get();
                echo "La consulta de este libro se hizo el: " .date("d-m-Y");
                echo " a las " .date("h:ia");
                echo " en " .$ZonaHorariaNY ;
                break;
            case 'Ciudad de México':
                date_default_timezone_set("America/Mexico_City");
                $ZonaHorariaNY= date_default_timezone_get();
                echo "La consulta de este libro se hizo el: " .date("d-m-Y");
                echo " a las " .date("h:ia");
                echo " en " .$ZonaHorariaNY ;
                break;
        }
        $fechaInicio= mktime(12, 20, 0, 12, 9, 1994);
        echo "<br> <br>";
        echo "Este libro se inicio el: " .date("d-m-Y" , $fechaInicio);
        // switch ($texto){
        //     case "Normal":
        //         for($i=0; $i<=1399; $i++){
        //             $lugar=rand(0,1399);
        //             $randconta=rand(65,126);
    
        //             $rand[$i]= chr($randconta);
    
        //                 if($lugar === $i){
        //                   $rand[$i] = $palabras;
        //                   echo "<strong>$rand[$i]</strong>";
        //                 } else{
        //                   echo $rand[$i];
        //                 }
        //         }; 
        //         break;
        //     case "Palabras":
        //         $limpal = explode(" ", $palabras);
        //         $longitud = count ($limpal);

        //         for($i=0; $i<=1399; $i++){
        //             $randconta=rand(65,126);
    
        //             $rand[$i]= chr($randconta);
        //         };

        //         for($i=0; $i<$longitud; $i++){
        //             $randconta=rand(0,1399);

        //             $rand[$randconta] = $limpal[$i];
        //         };

        //         for($i=0; $i<=1399; $i++){
        //             if ($cuenta >=70) {
        //                 echo "     ";
        //                 echo $rand[$i];
        //                 echo "     ";
        //                 echo "<br>";
        //                 $cuenta=1;
        //             } else {
        //                 echo "     ";
        //                 echo $rand[$i];
        //                 echo "     ";
        //             }
        //             $cuenta++;
        //         };
        //         break;
        //     case "Orden":
        //         $lugar=rand(0,1399);
        //         $limpal = explode(" ", $palabras);
        //         $longitud = count ($limpal);
        //         $max= $lugar + $longitud;

        //         shuffle($limpal);
        //         $contPals=0;

        //         for($i=0; $i<=1399; $i++){
        //             $randconta=rand(65,126);
    
        //             $rand[$i]= chr($randconta);
        //         };

        //         for($i = $lugar; $i < $max ; $i++){
        //             $rand[$i]= $limpal[$contPals];
        //             $contPals++;
        //         };
        //         for($i=0; $i<=1399; $i++){
        //             if ($cuenta >=90) {
        //                 echo $rand[$i]."<br>";
        //                 $cuenta=1;
        //             } else {
        //                 echo $rand[$i];
        //             }
        //             $cuenta++;
        //         };
        //         break;
        // }
    ?>
</body>
</html>