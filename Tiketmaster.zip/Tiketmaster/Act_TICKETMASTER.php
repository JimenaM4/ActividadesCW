<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BOLETOS Ticketmaster</title>
    <link rel="icon" href="./Multimedia/ticketmaster_icono.jpg" type="image/x-icon">
</head>
<body bgcolor="E8F6EF">
	<font color="#000000">
    <h1 align="center">Tus boletos</h1>
    <?php
        $nombre=(isset($_POST['nombre']) && $_POST["nombre"] != "")? $_POST['nombre'] : "Falta Valor";
        $apellido=(isset($_POST['apellido']) && $_POST["apellido"] !="")?$_POST['apellido'] : "Falta Valor";
        $fecha=(isset($_POST['fecha']) && $_POST["fecha"] != "")? $_POST['fecha'] : "Falta Valor";
        $artista=(isset($_POST['artista']) && $_POST["artista"] !="")?$_POST['artista'] : "Falta Valor";
        $zona=(isset($_POST['zona']) && $_POST["zona"] != "")? $_POST['zona'] : "Falta Valor";
        $boletos=(isset($_POST['boletos']) && $_POST["boletos"] !="")?$_POST['boletos'] : "Falta Valor";
        $lugar=(isset($_POST['lugar']) && $_POST["lugar"] != "")? $_POST['lugar'] : "Falta Valor";
        $extras1=(isset($_POST['extras1']) && $_POST["extras1"] !="")?$_POST['extras1'] : "Falta Valor";
        $extras2=(isset($_POST['extras2']) && $_POST["extras2"] !="")?$_POST['extras2'] : "Falta Valor";
        $extras3=(isset($_POST['extras3']) && $_POST["extras3"] !="")?$_POST['extras3'] : "Falta Valor";
        //variables
        $imagenAr;
        $imagenz;
        $imagenLugar;
        $alto;
        $ancho;
        $frase;
        //Condicionales para cada artista 
        if ($artista=="Ed Sheeran")
        {
            $imagenAr="./Multimedia/EdSheeran.jpg";
            $alto="150";
            $ancho="200";
            $frase="Everything will be all right at the end of the road. And if it doesn't work out, then it's not the end";
        }else if ($artista=="Conan Gray")
        {
            $imagenAr="./Multimedia/ConanGray.jpg";
            $alto="150";
            $ancho="200";
            $frase="We're two worlds apart";
        }else if ($artista=="Benson Boone")
        {
            $imagenAr="./Multimedia/BensonBoone.jpg";
            $alto="200";
            $ancho="150";
            $frase="Maybe loving me's the reason you can't love yourself";
        } else {
            $imagenAr="./Multimedia/NathanWagner.jpg";
            $alto="200";
            $ancho="200";
            $frase="Is everybody lonely? Is everybody scared? Is everybody worried That no one really cares?";
        }
        //condicionales para la imagen del lugar
        if ($lugar=="Auditorio Nacional")
        {
            $imagenLugar="./Multimedia/auditorio.jpg";
        }
        if ($lugar=="Palacio de los Deportes")
        {
            $imagenLugar="./Multimedia/palacio_deportes.webp";
        }
        if ($lugar=="Foro Sol")
        {
            $imagenLugar="./Multimedia/foro_sol_.webp";
        }
        if ($lugar=="Teatro Metropolitan")
        {
            $imagenLugar="./Multimedia/teatro_metropolitan.jpg";
        }
        //condicionales para la imagen de la zona
        if ($zona=="Gold")
        {
            $imagenz="./Multimedia/zonas.jpeg";
        }
        if ($zona=="VIP")
        {
            $imagenz="./Multimedia/VIP.jpg";
        }
        if ($zona=="Platinum")
        {
            $imagenz="./Multimedia/zonas.jpeg";
        }
        if ($zona=="Bronce")
        {
            $imagenz="./Multimedia/zonas.jpeg";
        }
        //BOLETOS
        for ($i=1;$i<=$boletos;$i++)
        {
            echo "<table border='2'align='center' style='border-collapse:collapse;' cellpadding='20px';>
            <thead>
                <tr>
                    <th colspan='4'>Boletos para $artista</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><strong>Datos:<strong></td>
                    <td>$nombre $apellido</td>
                    <td>Fecha: $fecha</td>
                    <td rowspan='3'><img src='$imagenAr' alt='$artista' width='$ancho' height='$alto'></td> 
                </tr>
                <tr>
                    <td><div align='center'>$lugar</div></td>
                    <td><div align='center'>$zona</div></td>";
                    echo "<td rowspan='2'>Extras:
                    <ul>";
                        if ($extras1==1)
                        {
                            echo "<li>Paquete de comida</li>";
                        }
                        if ($extras2==2)
                        {
                            echo "<li>Paquete VIP</li>";
                        }
                        if ($extras3==3)
                        {
                            echo "<li>Estacionamiento</li>";
                        }
                   echo "</ul>
                    </td>
                </tr>
                <tr>
                    <th><div align='center'><img src='$imagenLugar' alt='$lugar' width='$ancho' height='$alto'></div></th>
                    <th><div align='center'><img src='$imagenz' alt='$zona' width='250' height='200'></div></th>
                </tr>
                <tr>
                    <th colspan='4'><div align='center'>$frase</div></th>
                </tr>
            </tbody>
        </table>";
        echo "<br><br>";
        } 
     ?>
</body>
</html>