<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Renombrar</title>
    <link rel="icon" href="../../Statics/media/icono_menu.png" type="image/x-png">
    <link rel="stylesheet" href="../../Statics/styles/style.css">
</head>
<body>
    <?php
    echo '<div class="renombrar">
        <h1 align="center">Especifica que archivo vas a renombrar</h1>
        <form align="center" action="./renombrar.php" method="post" target="_self">
            <fieldset> 
                <legend align="center">¿Archivo o carpeta?</legend><br><br>
                    <label>
                    <input type="radio" name="archivo" checked value="1"><br>Carpeta<br><br>
                    <input type="radio" name="archivo" checked value="2"><br>Archivo<br><br>
                    <label for="nombreact">Nombre del archivo o carpeta<br><br></label>
                    <input type="text" id="nombreact" name="nombreact" required/><br><br>
                    <label for="nombrenew">Nuevo nombre del archivo o carpeta<br><br></label>
                    <input name="nombrenew" id="nombrenew" type="text" required/><br><br>
                    <br>
                    <button type="submit">Renombrar</button>
            </fieldset>
        </form>';
        $archivo=(isset($_POST['archivo']) && $_POST["archivo"] != "")? $_POST['archivo'] : false;
        $nombreact=(isset($_POST['nombreact']) && $_POST["nombreact"] != "")? $_POST['nombreact'] : false;
        $nombrenew=(isset($_POST['nombrenew']) && $_POST["nombrenew"] != "")? $_POST['nombrenew'] : false;
        $base="C:\XAMPP\htdocs\php\Act_explorador_de_archivos\Dynamics\PHP";
        if($archivo==1){
            rename($nombreact,$nombrenew);
        }
        if($archivo==2){
            rename($nombreact, $nombrenew); 
        }
    ?>
    <a align="center" href="http://localhost/Curso_Web/php/Act_explorador_de_archivos/Dynamics/PHP/menu.php?actividad=2">Continuar</a>
    </div>
</body>
</html>