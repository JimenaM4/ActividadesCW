<?php
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Explorador de archivos</title>
    <link rel="icon" href="../../Statics/media/icono_menu.png" type="image/x-png">
    <link rel="stylesheet" href="../../Statics/styles/style.css">
</head> 
<body>  
<div class="contenedor">
    <?php  
     $usuario=(isset($_POST['usuario']) && $_POST["usuario"] != "")? $_POST['usuario'] : false;
     $casa=(isset($_POST['casa']) && $_POST["casa"] != "")? $_POST['casa'] : false;
     $accion=(isset($_POST['accion']) && $_POST["accion"] != "")? $_POST['accion'] : false;
     $duracion= time()+60*20;
     if(isset($_COOKIE["user"])==false)
     {
        setcookie("user", $usuario, $duracion); 
        setcookie("casa", $casa, $duracion); 
        $usuario=$_COOKIE["user"]; 
        $casa2=$_COOKIE["casa"];
     }
        echo "<h1 align='center'>¿Que quieres hacer $usuario?</h1>";
        echo "
        <form align='center' action='./menu.php' method='post' target='_self'>
            <fieldset>
                <legend align='center'>¿Archivo o carpeta?</legend><br>
                    <button name='accion' value='1'>Crear</button><br><br>
                    <button name='accion' value='2'>Renombrar</button><br><br>
                    <button name='accion' value='3'>Eliminar</button><br><br>
                    <button name='accion' value='5'>Salir</button>
                    <br><br>
            </fieldset>
        </form>";
        switch($accion)
        {
                case "1":
                    header('LOCATION:./crear.php');
                    break;
                case "2":
                    header('LOCATION:./renombrar.php');
                    break;
                case "3":
                    header('LOCATION:./eliminar.php');
                    break; 
                case "5":
                    header('LOCATION:../../../Templates/Registro.html');
                    break;
        };

            $actividad=$_GET['actividad'];

            if ($actividad!=false) 
            {
                echo "<br><center>REGISTRO DE ACTIVIDAD</center><br>";
                if ($actividad==1){
                    echo "El usuario $usuario de la casa $casa2 creó un archivo";
                }
                if ($actividad==2){
                    echo "El usuario $usuario de la casa $casa2 renombró un archivo";
                }
                if ($actividad==3){
                    echo "El usuario $usuario de la casa $casa2 eliminó un archivo";
                }
            }
       
            
    ?>
</div> 
</body>
</html>