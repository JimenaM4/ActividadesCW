<!DOCTYPE html>
<html lang="en">
<head> 
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminar</title>
    <link rel="icon" href="../../Statics/media/icono_menu.png" type="image/x-png">
    <link rel="stylesheet" href="../../Statics/styles/style.css">
</head>
<body>
    <div class="contenedor">
    <h1 align="center">Especifica que archivo vas a eliminar</h1>
        <form align="center" action="./eliminar.php" method="post" target="_self">
            <fieldset>
                <legend align="center">¿Archivo o carpeta?</legend><br>
                    <label>
                    <input class="radio" type="radio" name="crear" checked value="1"><br>Carpeta<br><br>
                    <input class="radio" type="radio" name="crear" checked value="2"><br>Archivo<br><br>
                    </label>
                    <label for="archivo">Nombre del archivo o carpeta<br><br></label>
                    <input type="text" id="archivo" name="archivo" required/><br><br>
                    <label><button type="submit">Eliminar</button></label>
            </fieldset>
        </form>  
    <?php
        $archivo=(isset($_POST['archivo']) && $_POST["archivo"] != "")? $_POST['archivo'] : false;
        $crear=(isset($_POST['crear']) && $_POST["crear"] != "")? $_POST['crear'] : false;
        if ($crear==1){
            rmdir($archivo);
        }
        if($crear==2){
           unlink($archivo);
        }
    ?>
     <a align="center" href="http://localhost/Curso_Web/php/Act_explorador_de_archivos/Dynamics/PHP/menu.php?actividad=3">Continuar</a>
    </div>
</body>
</html>